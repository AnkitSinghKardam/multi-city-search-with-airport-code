/*one way round trip radio button js*/
$(function () {
        $("#oneWay").click(function () {
            if ($(this).is(":checked")) {
				$(".form-check-label span").removeClass("ifChecked");
				$(this).closest(".form-check-label").find("span").addClass("ifChecked");
				$(".form-check-label").removeClass("colorBlack");
				$(this).closest(".form-check-label").addClass("colorBlack");
				$(".oneWayMsg").css({"top" : "0px"});
				$(".makeFromCalFromFirstCal").hide();
				$(".makeFromCalto").hide();
				$(".makeFromCalFromSingle").show();
				$(".makeFromTravellers").addClass("width34");
            } 
        });
    });
$(function () {
        $("#roundTrip").click(function () {
            if ($(this).is(":checked")) {
				$(".form-check-label span").removeClass("ifChecked");
				$(this).closest(".form-check-label").find("span").addClass("ifChecked");
				$(".form-check-label").removeClass("colorBlack");
				$(this).closest(".form-check-label").addClass("colorBlack");
				$(".oneWayMsg").css({"top" : "-110px"});
				$(".makeFromCalFromFirstCal").show();
				$(".makeFromCalto").show();
				$(".makeFromCalFromSingle").hide();
				$(".makeFromTravellers").removeClass("width34");
            } 
        });
    });
/*one way round trip radio button js*/

$(".makeFromTravellers").click(function(){
	$(".travllerCounter").show();
	event.stopPropagation();
});

$('body').click(function(){
	$(".travllerCounter").hide();
})
$('select').on('change', function () {
     var selectedValue = this.selectedOptions[0].value;
     var selectedText  = this.selectedOptions[0].text;
	 $(".classVal").text(selectedText);
});

$(".aPlus").on("click", function(){
	if($(".adultValue").val() >= 9){
		alert("aPlus");
	}else{
		var adult = $(".adultValue").val();
		var adultInt = parseInt(adult);
		$(".adultValue").val(adultInt + 1);		
	}
});

$(".aMinus").on("click", function(){
	if($(".adultValue").val() == 1){
		alert("aMinus");		
	}else{
		var adult = $(".adultValue").val();
		var adultInt = parseInt(adult);
		$(".adultValue").val(adultInt - 1);		
	}
});

$(".cPlus").on("click", function(){
	if($(".childrenValue").val() >= 6){
		alert("cPlus");
	}else{
		var child = $(".childrenValue").val();
		var childInt = parseInt(child);
		$(".childrenValue").val(childInt + 1);	
	}
});

$(".cMinus").on("click", function(){
	if($(".childrenValue").val() == 0){
		alert("cMinus");		
	}else{
		var child = $(".childrenValue").val();
		var childInt = parseInt(child);
		$(".childrenValue").val(childInt - 1);	
	}
});

$(".iPlus").on("click", function(){
	if($(".infantsValue").val() >= 6){
		alert("iPlus");
	}else{
		var infant = $(".infantsValue").val();
		var infantInt = parseInt(infant);
		$(".infantsValue").val(infantInt + 1);	
	}
});

$(".iMinus").on("click", function(){
	if($(".infantsValue").val() == 0){
		alert("iMinus");		
	}else{
		var infant = $(".infantsValue").val();
		var infantInt = parseInt(infant);
		$(".infantsValue").val(infantInt - 1);
	}

});

$(function(){
            $('.mmtAdult div:nth-child(2) span').on('click',function(){
               var value1 = parseInt($(".adultValue").val()) || 0;
               var value2 = parseInt($(".childrenValue").val()) || 0;
               var value3 = parseInt($(".infantsValue").val()) || 0;
               $('.numOfTravller').val(value1 + value2 + value3);	
					if($('.numOfTravller').val() <= 1){
						$('.numOfTravller').val(value1 + value2 + value3 + " " + "Traveller");
					}
					else{
						$('.numOfTravller').val(value1 + value2 + value3 + " " + "Travellers");
					}	
            });
});

/*Customize calander js*/
$(document).ready(function() {
     $("#firstCalDateParent").text(moment().format('DDMMMYYYY'));
	 $("#firstCalDate").text($("#firstCalDateParent").text().slice(0, 2));
	 $("#firstCalMonth").text($("#firstCalDateParent").text().slice(2, 5));
	 $("#firstCalYear").text($("#firstCalDateParent").text().slice(5, 9));

     $("#lastCalDateParent").text(moment().format('DDMMMYYYY'));	 
	 $("#lastCalDate").text($("#lastCalDateParent").text().slice(0, 2));
	 $("#lastCalMonth").text($("#lastCalDateParent").text().slice(2, 5));
	 $("#lastCalYear").text($("#lastCalDateParent").text().slice(5, 9));
	 
     $("#result-1").text(moment().format('DDMMMYYYY'));	 
	 $("#singleCalDate").text($("#result-1").text().slice(0, 2));
	 $("#singleCalMonth").text($("#result-1").text().slice(2, 5));
	 $("#singleCalYear").text($("#result-1").text().slice(5, 9));
});
/*Customize calander js*/