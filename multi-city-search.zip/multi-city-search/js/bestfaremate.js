$(window).scroll(function() {
  if ($(document).scrollTop() > 50) {
    $('nav').addClass('shrink');
  } else {
    $('nav').removeClass('shrink');
  }
});




function assignSampleClick() {
	$('.airCanadaAiroplan img').css({"left" : "0px"});
}

// document ready
$(function() {
    setTimeout(assignSampleClick, 50);
});

/*Slide Toggle for busniss class*/

$("#validate-input-group-me").click(function(e){
	e.stopPropagation();
    $("#econemyGroup").slideToggle();
});

$("#econemyGroup li").click(function(){
	$(".preClass").val($(this).text());
	$("#econemyGroup").slideToggle();
	//alert($(".preClass").val());
});

$("#validate-input-group-me-popUp").click(function(){
    $("#econemyGroup-pop").slideToggle();
});

$("#econemyGroup-pop li").click(function(){
	$(".preClasspop").val($(this).text());
	$("#econemyGroup-pop").slideToggle();
});
/*Slide Toggle for busniss class*/
/*Slide Toggle for number of passenger class*/


(function($) {
  
  $("#sumofPsngr").click(function(e){
    e.stopPropagation();
    var div = $("#numberOfPassenger");
	$("#numberOfPassenger").slideDown();
  });
$(document).click(function(e){
  $('#numberOfPassenger').slideUp();
  $('#econemyGroup').slideUp();
  //$(".united-tab-content-popup").hide();
});
})(jQuery);
$("#numberOfPassenger").click(function(e){
   e.stopPropagation();
});
$(".united-tab-content-popup").click(function(e){
   e.stopPropagation();
});

/*

$("#sumofPsngr").click(function(){
  $("#numberOfPassenger").slideDown();
});


*/
$("#flightMybutton button").click(function(){
  $("#numberOfPassenger").slideUp();
});


$("#sumofPsngrpop").click(function(){
  $("#numberOfPassengerpop").slideDown();
});

$("#flightMybuttonpop button").click(function(){
  $("#numberOfPassengerpop").slideUp();
});

function up11(max) {
    document.getElementById("myNumber11").value = parseInt(document.getElementById("myNumber11").value) + 1;
    if (document.getElementById("myNumber11").value >= parseInt(max)) {
        document.getElementById("myNumber11").value = max;
    }
}
function down11(min) {
    document.getElementById("myNumber11").value = parseInt(document.getElementById("myNumber11").value) - 1;
    if (document.getElementById("myNumber11").value <= parseInt(min)) {
        document.getElementById("myNumber11").value = min;
    }
}
function up12(max) {
    document.getElementById("myNumber12").value = parseInt(document.getElementById("myNumber12").value) + 1;
    if (document.getElementById("myNumber12").value >= parseInt(max)) {
        document.getElementById("myNumber12").value = max;
    }
}
function down12(min) {
    document.getElementById("myNumber12").value = parseInt(document.getElementById("myNumber12").value) - 1;
    if (document.getElementById("myNumber12").value <= parseInt(min)) {
        document.getElementById("myNumber12").value = min;
    }
}
function up13(max) {
    document.getElementById("myNumber13").value = parseInt(document.getElementById("myNumber13").value) + 1;
    if (document.getElementById("myNumber13").value >= parseInt(max)) {
        document.getElementById("myNumber13").value = max;
    }
}
function down13(min) {
    document.getElementById("myNumber13").value = parseInt(document.getElementById("myNumber13").value) - 1;
    if (document.getElementById("myNumber13").value <= parseInt(min)) {
        document.getElementById("myNumber13").value = min;
    }
}


$(function(){
            $('#numberOfPassenger span').on('click',function(){
               var value1 = parseInt($('#myNumber11').val()) || 0;
               var value2 = parseInt($('#myNumber12').val()) || 0;
               var value3 = parseInt($('#myNumber13').val()) || 0;
			   
               $('#sumofPsngr').val(value1 + value2 + value3);
			   
				if($('#sumofPsngr').val() == 0){
					$('#sumofPsngr').val("Passenger");
				}
			    else if($('#sumofPsngr').val() <= 1){
					$('#sumofPsngr').val(value1 + value2 + value3 + " " + "Passenger");
				}
				else{
					$('#sumofPsngr').val(value1 + value2 + value3 + " " + "Passengers");
				}	
            });
         });
		 

		 
/*Another*/
function up119(max) {
    document.getElementById("myNumber119").value = parseInt(document.getElementById("myNumber119").value) + 1;
    if (document.getElementById("myNumber119").value >= parseInt(max)) {
        document.getElementById("myNumber119").value = max;
    }
}
function down119(min) {
    document.getElementById("myNumber119").value = parseInt(document.getElementById("myNumber119").value) - 1;
    if (document.getElementById("myNumber119").value <= parseInt(min)) {
        document.getElementById("myNumber119").value = min;
    }
}
function up129(max) {
    document.getElementById("myNumber129").value = parseInt(document.getElementById("myNumber129").value) + 1;
    if (document.getElementById("myNumber129").value >= parseInt(max)) {
        document.getElementById("myNumber129").value = max;
    }
}
function down129(min) {
    document.getElementById("myNumber129").value = parseInt(document.getElementById("myNumber129").value) - 1;
    if (document.getElementById("myNumber129").value <= parseInt(min)) {
        document.getElementById("myNumber129").value = min;
    }
}
function up139(max) {
    document.getElementById("myNumber139").value = parseInt(document.getElementById("myNumber139").value) + 1;
    if (document.getElementById("myNumber139").value >= parseInt(max)) {
        document.getElementById("myNumber139").value = max;
    }
}
function down139(min) {
    document.getElementById("myNumber139").value = parseInt(document.getElementById("myNumber139").value) - 1;
    if (document.getElementById("myNumber139").value <= parseInt(min)) {
        document.getElementById("myNumber139").value = min;
    }
}


$(function(){
            $('#numberOfPassengerpop span').on('click',function(){
               var value1 = parseInt($('#myNumber119').val()) || 0;
               var value2 = parseInt($('#myNumber129').val()) || 0;
               var value3 = parseInt($('#myNumber139').val()) || 0;
			   
               $('#sumofPsngrpop').val(value1 + value2 + value3);
			   
				if($('#sumofPsngrpop').val() == 0){
					$('#sumofPsngrpop').val("Passenger");
				}
			    else if($('#sumofPsngrpop').val() <= 1){
					$('#sumofPsngrpop').val(value1 + value2 + value3 + " " + "Passenger");
				}
				else{
					$('#sumofPsngrpop').val(value1 + value2 + value3 + " " + "Passengers");
				}	
            });
         });
		 

/*Another*/
/*Slide Toggle for number of passenger class*/


// When the DOM is ready, run this function
$(document).ready(function() {
  //Set the carousel options
  $('#quote-carousel').carousel({
    pause: true,
    interval: 2500,
  });
});


//hide js on radio button
$(function () {
        $("#option2").click(function () {
            if ($(this).is(":checked")) {
                $(".myHide").hide();
				$(".width-xs-full").removeClass("col-xs-6");
				$(".width-xs-full").addClass("col-xs-12");
            } 
        });
    });
$(function () {
        $("#option1").click(function () {
            if ($(this).is(":checked")) {
                $(".myHide").show();
				$(".width-xs-full").removeClass("col-xs-12");
				$(".width-xs-full").addClass("col-xs-6");
            } 
        });
    });
//hide js on radio button

/*Onload call us Pop up*/

  $(".arange").click(function(){
    $("#msg").animate({bottom: "50px"});
  });

  $('.close-msg').click(function() {
	$( "#msg" ).animate({bottom: "-250px"});
  });
/*Onload call us Pop up*/


/*dapepicker radio button js*/
$(function () {
        $("#option4").click(function () {
            if ($(this).is(":checked")) {
                $(".myHidePopup").hide();
				$(".widthFullPopup").removeClass("col-sm-6");
				$(".widthFullPopup").addClass("col-sm-12");
				$(".Zebra_DatePicker_Icon_Wrapper").addClass("mywidth");
            } 
        });
    });
$(function () {
        $("#option3").click(function () {
            if ($(this).is(":checked")) {
                $(".myHidePopup").show();
				$(".widthFullPopup").removeClass("col-sm-12");
				$(".widthFullPopup").addClass("col-sm-6");
				$(".Zebra_DatePicker_Icon_Wrapper").removeClass("mywidth");
            } 
        });
    });
/*dapepicker radio button js*/



/*show div find closest div and add a div with datepicker calander js*/

var divVariable = $('.anky');

$(".ankit").click(function(e) {
	e.stopPropagation();
  $(".united-tab-content-popup").css({"visibility" : "visible"});
  $(".united-tab-content-popup").show();
  $(this).closest('.col-md-12').find(".ankit1").after(divVariable);

  
  var a = $(this).closest('.col-md-12').find(".x").text();
  var b = $(this).closest('.col-md-12').find(".y").text();
  
  $("#datepicker-range-start").val(a);
  $("#datepicker-range-end").val(b);
  
  $("#datepicker-range-start-99").val(a);
  $("#datepicker-range-end-99").val(b);
  
});
$(".unitedClosePopUp").click(function(){
	$(".united-tab-content-popup").hide();
});

/*show div find closest div and add a div with datepicker calander js*/


$("#option15").click(function(){

});

$("#option25").click(function(){

});

$(".form-group-united-radio-popUp").click(function(){

});


/*Calander js code for disabled back date*/
    $(function(){
	$('.calanderPopUpCssBlock').Zebra_DatePicker(); 
    $('#datepicker-range-end-99').Zebra_DatePicker({
        direction: 1
    });

    $('#datepicker-range-start-99').Zebra_DatePicker({
        direction: true,
        pair: $('#datepicker-range-end-99')
    });	
	}); 
/*Calander js code for disabled back date*/

/*show div find closest div and add a div with datepicker calander js*/


$("#option15").click(function(){

});

$("#option25").click(function(){

});

$(".form-group-united-radio-popUp").click(function(){

});

$(".openFormForSraching").click(function(){
	$(".modifiedSearchResult").slideToggle();
	$(".modifiedSearchBlock i").toggleClass("ninteenDegree");
});

$(".flightDetailsFirst").click(function(){
	$(".inbondOutbondResultParent").slideToggle();
});